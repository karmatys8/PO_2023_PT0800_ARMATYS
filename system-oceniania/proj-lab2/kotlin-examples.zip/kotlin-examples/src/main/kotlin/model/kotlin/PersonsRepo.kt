package model.kotlin


class PersonsRepo {

    fun registerPerson(person: Person) {
        TODO()
    }

    fun getAllSurnames() {
        TODO()
    }

    fun findByFullName(fullName: String) {
        TODO()
    }
}
