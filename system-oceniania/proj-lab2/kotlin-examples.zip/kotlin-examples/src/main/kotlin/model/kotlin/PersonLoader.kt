package model.kotlin

import java.io.File
import java.io.IOException

class PersonLoader(private val filePath: String) {
//
//    @Throws(IOException::class)
//    fun loadPersonsFromFile(handler: (Person) -> Unit) {
//        return File(filePath).useLines { lines ->
//            lines.map { loadPerson(it) }
//                .forEach(handler)
//        }
//    }
//
//    private fun loadPerson(line: String): Person {
//        val lineParts = line.split(";")
//        require(lineParts.size >= 2) { "Person data should have at least name and surname" }
//
//        return Person(
//            name = lineParts[0],
//            surname = lineParts[1],
//            address = loadAddress(lineParts)
//        )
//    }
//
//    private fun loadAddress(lineParts: List<String>): Address? {
//        return if (lineParts.size > 2) {
//            Address(
//                city = lineParts[2],
//                postalCode = if (lineParts.size > 3) lineParts[3] else null,
//                street = if (lineParts.size > 4) lineParts[4] else null,
//                province = if (lineParts.size > 5) lineParts[5] else null,
//                details = if (lineParts.size > 6) lineParts[6] else null
//            )
//        } else null
//    }
}
