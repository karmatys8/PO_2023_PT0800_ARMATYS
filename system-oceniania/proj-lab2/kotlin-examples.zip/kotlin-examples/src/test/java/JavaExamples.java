import model.java.Address;
import model.java.Person;
import model.java.PersonLoader;
import model.java.PersonsRepo;
import model.java.util.RepoUtil;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class JavaExamples {

    /**
     * Problem 1
     */
    @Test
    public void dataClassExample() {
        var person = new Person("Piotr", "Budynek");
        person.setSurname("Fundament");

        System.out.println(person);
    }

    /**
     * Problem 2
     */
    @Test
    public void builderExample() {
        // no builder
        var address = new Address(null, "Krakow", "30-059", null, null);

        // with builder
        address = Address.builder()
                .city("Krakow")
                .postalCode("30-059")
                .build();

        System.out.println(address);
    }

    /**
     * Problem 3
     */
    @Test
    public void collectionsExample() {
        var exampleRepo = createExampleRepo();

        List<String> allSurnames = exampleRepo.getAllSurnames();
        allSurnames.add("Hakier");
        System.out.println(allSurnames.get(0));
    }

    /**
     * Problem 4
     */
    @Test
    public void optionalExample() {
        var exampleRepo = createExampleRepo();

        // Pure objective style
        Optional<Person> foundPerson = exampleRepo.findByFullName("Piotr Budynek");
        if (foundPerson.isPresent()) {
            Optional<Address> address = foundPerson.get().getAddress();

            if (address.isPresent()) {
                Optional<String> city = address.get().getCity();

                if (city.isPresent()) {
                    System.out.println(city.get());
                }
            }
        }

        // Functional style
        exampleRepo.findByFullName("Piotr Budynek")
                .flatMap(Person::getAddress)
                .flatMap(Address::getCity)
                .ifPresent(System.out::println);
    }

    /**
     * Problem 5
     */
    @Test
    public void extensionsExample() {
        // custom class extensions
        var person = new Person("Ala", "Makota");
        System.out.println(RepoUtil.getFullName(person));

        // library class extensions
        System.out.println(RepoUtil.removePolishCharacters("zażółć gęślą jaźń"));

        // generics extensions
        List<Address> addresses = List.of(Address.builder().city("Krakow").build(),
                Address.builder().street("Mickiewicza").build(),
                Address.builder().city("Warszawa").build());

        RepoUtil.withFilledCity(addresses)
                .forEach(RepoUtil::logInfo);

        RepoUtil.logInfo("jakis tekst");
        RepoUtil.logInfo(666);
    }

    /**
     * Problem 6
     */
    @Test
    public void controlFlowExample() {
        var person = createExamplePersonWithAddress();

        List<String> personData = new ArrayList<>();

        personData.add(RepoUtil.getFullName(person));
        person.getAddress().ifPresent(address -> personData.add(address.toString()));

        List<String> normalizedPersonData = personData.stream()
                .map(RepoUtil::removePolishCharacters)
                .collect(Collectors.toList());


        var descriptor = new Descriptor(normalizedPersonData);

        fillDescriptor(descriptor);

        System.out.println(descriptor);
    }

    /**
     * Problem 6, pt. 2
     */
    @Test
    public void changePersonDataExample() {
        var person = createExamplePersonWithAddress();

        person.setSurname("Chałupa");
        person.setAddress(Address.builder()
                .city("Warszawa")
                .postalCode("30-059")
                .build());

        System.out.println(person);
    }

    /**
     * Problem 7
     */
    @Test
    public void advancedErrorHandlingExample() {
        var personRepo = new PersonsRepo();
        var personLoader = new PersonLoader("sample_error.csv");

        try {
            personLoader.loadPersonsFromFile()
                    .forEach(person -> personRepo.registerPerson(person));

        } catch (IOException e) {
            System.out.println("File reading error");
        }
        System.out.println(personRepo);
    }

    private PersonsRepo createExampleRepo() {
        var personWithAddress = createExamplePersonWithAddress();
        var personWithoutAddress = new Person("Krystyna", "Chałupa");

        var personsRepo = new PersonsRepo();
        personsRepo.registerPerson(personWithAddress);
        personsRepo.registerPerson(personWithoutAddress);

        return personsRepo;
    }


    private void fillDescriptor(Descriptor descriptor) {
        descriptor.fillMetadata(Map.of("createdDate", LocalDate.now().toString()));
    }

    private Person createExamplePersonWithAddress() {
        var address = Address.builder()
                .city("Krakow")
                .postalCode("30-059")
                .build();

        return new Person("Piotr", "Budynek", address);
    }

    private static class Descriptor {
        private final List<String> personDetails;

        private final Map<String, String> metadata = new HashMap<>();

        private Descriptor(List<String> personDetails) {
            this.personDetails = personDetails;
        }

        public void fillMetadata(Map<String, String> metadata) {
            this.metadata.putAll(metadata);
        }

        @Override
        public String toString() {
            return "Descriptor{" +
                    "personDetails=" + personDetails +
                    ", metadata=" + metadata +
                    '}';
        }
    }
}
