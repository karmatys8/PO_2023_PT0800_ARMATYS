import model.kotlin.Address
import model.kotlin.Person
import model.kotlin.PersonLoader
import model.kotlin.PersonsRepo
import org.junit.jupiter.api.Test
import java.math.BigInteger
import java.time.LocalDate
import java.util.Random
import kotlin.system.measureTimeMillis

class KotlinExamples {

    /**
     * Problem 1
     */
    @Test
    fun dataClassExample() {
        val person: Person = TODO()

        println(person)
    }

    /**
     * Problem 2
     */
    @Test
    fun builderExample() {
        val address: Address = TODO()
        println(address)
    }

    /**
     * Problem 3
     */
    @Test
    fun collectionsExample() {
        val exampleRepo = createExampleRepo()
        TODO()
    }

    /**
     * Problem 4
     */
    @Test
    fun optionalExample() {
        val personsRepo = createExampleRepo()

        TODO()
    }

    /**
     * Problem 5
     */
    @Test
    fun extensionsExample() {
        val person = TODO()

        println("zażółć gęślą jaźń")

        val addresses =
            TODO() // listOf(Address(city = "Krakow"), Address(street = "Mickiewicza"), Address(city = "Warszawa"))
    }

    /**
     * Problem 6
     */
    @Test
    fun controlFlowExample() {
        TODO()
//        val person = createExamplePersonWithAddress()
//
//        val personData = mutableListOf<String>()
//
//        personData.add(person.fullName())
//
//        if (person.address != null) {
//            personData.add(person.address.toString())
//        }
//
//        val normalizedPersonData = personData.map { it.removePolishCharacters() }
//
//        val descriptor = Descriptor(normalizedPersonData)
//        fillDescriptor(descriptor)
//
//        println(descriptor)
    }

    /**
     * Problem 6, pt. 2
     */
    @Test
    fun changePersonDataExample() {
        val person = createExamplePersonWithAddress()

        TODO()

        println(person)
    }

    /**
     * Problem 7
     */
    @Test
    fun advancedErrorHandlingExample() {
        val personRepo = PersonsRepo()
        val personLoader = PersonLoader("sample.csv")

        TODO()
//        try {
//            personLoader.loadPersonsFromFile {
//                personRepo.registerPerson(it)
//            }
//        } catch (e: IOException) {
//            println("File reading error")
//            e.printStackTrace()
//        }
        println(personRepo)
    }

    private fun createExampleRepo(): PersonsRepo {
        TODO()
//        val personWithAddress = createExamplePersonWithAddress()
//        val personWithoutAddress = Person("Krystyna", "Chałupa")
//
//        val personsRepo = PersonsRepo()
//        personsRepo.registerPerson(personWithAddress)
//        personsRepo.registerPerson(personWithoutAddress)
//        return personsRepo
    }

    private fun fillDescriptor(descriptor: Descriptor) {
        descriptor.fillMetadata(mapOf("createdDate" to LocalDate.now().toString()))
    }

    private fun createExamplePersonWithAddress(): Person {
        TODO()
//        val address = Address(
//            city = "Krakow",
//            postalCode = "30-059"
//        )
//        return Person("Piotr", "Budynek", address)
    }

    private class Descriptor(private val personDetails: List<String>) {

        private val metadata: MutableMap<String, String> = mutableMapOf()

        fun fillMetadata(metadata: Map<String, String>) {
            this.metadata.putAll(metadata)
        }

        override fun toString(): String = "Descriptor{personDetails=$personDetails, metadata=$metadata}"
    }
}
