import model.kotlin.*
import model.kotlin.util.fullName
import model.kotlin.util.logInfo
import model.kotlin.util.removePolishCharacters
import model.kotlin.util.withFilledCity
import org.junit.jupiter.api.Test
import java.io.IOException
import java.math.BigInteger
import java.time.LocalDate
import java.util.Random
import kotlin.system.measureTimeMillis

class KotlinExamples {

    /**
     * Problem 1
     */
    @Test
    fun dataClassExample() {
        val person = Person("Michal", "Idzik")

        println(person)
    }

    /**
     * Problem 2
     */
    @Test
    fun builderExample() {
        val address = Address(postalCode = "30-059", city = "Krakow")
        println(address)

        val address2 = address.copy(city = "Warszawa", street = "Aleje Jerozolimskie")
        println(address2)
    }

    /**
     * Problem 3
     */
    @Test
    fun collectionsExample() {
        val exampleRepo = createExampleRepo()

        val allSurnames = exampleRepo.getAllSurnames()
        println(allSurnames)
    }

    /**
     * Problem 4
     */
    @Test
    fun optionalExample() {
        val personsRepo = createExampleRepo()

        personsRepo.findByFullName("Piotr Budynek")
            ?.address
            ?.city
            ?.let { println(it) }
    }

    /**
     * Problem 5
     */
    @Test
    fun extensionsExample() {
        val person = Person("Piotr", "Budynek")
        println(person.fullName()) // extension function
        println(person.fullName) // extension property

        println("zażółć gęślą jaźń".removePolishCharacters())

        val addresses = listOf(Address(city = "Krakow"), Address(street = "Mickiewicza"), Address(city = "Warszawa"))
        println(addresses.withFilledCity())

        person.logInfo() // mozna wolac na dowolnym typie
        addresses.logInfo() // ...a wiec rowniez kolekcji
        666.logInfo() // ...a nawet robic takie szatanizmy
    }

    /**
     * Problem 6
     */
    @Test
    fun controlFlowExample() {
        val person = createExamplePersonWithAddress()

        val descriptor = mutableListOf<String>()
            .apply { createPersonData(person) }
            .map { it.removePolishCharacters() }
            .let { Descriptor(it) }
            .also { fillDescriptor(it) }

        println(descriptor)
    }

    private fun MutableList<String>.createPersonData(person: Person) {
        add(person.fullName())

        if (person.address != null) {
            add(person.address.toString())
        }
    }

    /**
     * Problem 6, pt. 2
     */
    @Test
    fun changePersonDataExample() {
        val person = createExamplePersonWithAddress()

        with(person) {
            surname = "Chalupa"
            address = Address(city = "Krakow")
        }


        println(person)
    }

    /**
     * Problem 7
     */
    @Test
    fun advancedErrorHandlingExample() {
        val personRepo = PersonsRepo()
        val personLoader = PersonLoader("dfsdf.csv")

        personLoader.loadPersonsFromFile { loadResult ->
            when (loadResult) {
                is LoadResult.Success -> personRepo.registerPerson(loadResult.person)
                is LoadResult.LineError -> println("Nie udalo sie wczytac linii: ${loadResult.line}")
                is LoadResult.FileError -> error("Nie udalo sie wczytac pliku")
            }
        }
        println(personRepo)
    }


    private fun createExampleRepo(): PersonsRepo {
        val personWithAddress = createExamplePersonWithAddress()
        val personWithoutAddress = Person("Krystyna", "Chałupa")

        val personsRepo = PersonsRepo()
        personsRepo.registerPerson(personWithAddress)
        personsRepo.registerPerson(personWithoutAddress)
        return personsRepo
    }

    private fun fillDescriptor(descriptor: Descriptor) {
        descriptor.fillMetadata(mapOf("createdDate" to LocalDate.now().toString()))
    }

    private fun createExamplePersonWithAddress(): Person {
        val address = Address(
            city = "Krakow",
            postalCode = "30-059"
        )
        return Person("Piotr", "Budynek", address)
    }

    private class Descriptor(private val personDetails: List<String>) {

        private val metadata: MutableMap<String, String> = mutableMapOf()

        fun fillMetadata(metadata: Map<String, String>) {
            this.metadata.putAll(metadata)
        }

        override fun toString(): String = "Descriptor{personDetails=$personDetails, metadata=$metadata}"
    }
}
