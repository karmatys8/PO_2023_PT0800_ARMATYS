package model.kotlin

import java.io.File
import java.io.IOException

sealed class LoadResult {
    data class Success(val person: Person) : LoadResult()

    data class LineError(val line: String) : LoadResult()

    object FileError : LoadResult()
}

class PersonLoader(private val filePath: String) {

    fun loadPersonsFromFile(handler: (LoadResult) -> Unit) {
        try {
            return File(filePath).useLines { lines ->
                lines.map { loadPerson(it) }
                    .forEach(handler)
            }
        } catch(e : IOException) {
            handler(LoadResult.FileError())
        }
    }

    private fun loadPerson(line: String): LoadResult {
        val lineParts = line.split(";")
        if(lineParts.size < 2) {
            return LoadResult.LineError(line)
        }

        return Person(
            name = lineParts[0],
            surname = lineParts[1],
            address = loadAddress(lineParts)
        ).let { LoadResult.Success(it) }
    }

    private fun loadAddress(lineParts: List<String>): Address? {
        return if (lineParts.size > 2) {
            Address(
                city = lineParts[2],
                postalCode = if (lineParts.size > 3) lineParts[3] else null,
                street = if (lineParts.size > 4) lineParts[4] else null,
                province = if (lineParts.size > 5) lineParts[5] else null,
                details = if (lineParts.size > 6) lineParts[6] else null
            )
        } else null
    }
}
