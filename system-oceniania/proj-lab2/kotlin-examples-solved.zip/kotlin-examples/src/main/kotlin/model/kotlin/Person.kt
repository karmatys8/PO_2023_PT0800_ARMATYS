package model.kotlin

data class Person(
    val name: String,
    var surname: String,
    var address: Address? = null
)
