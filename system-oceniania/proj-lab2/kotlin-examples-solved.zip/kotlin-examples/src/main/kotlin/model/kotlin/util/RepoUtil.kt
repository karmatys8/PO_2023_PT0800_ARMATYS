package model.kotlin.util

import model.kotlin.Address
import model.kotlin.Person
import java.text.Normalizer
import java.time.LocalDate


// Extension function dla naszej wlasnej klasy
fun Person.fullName() : String = "$name $surname"

// ...mozna uzyskac to samo rowniez jako extension property
val Person.fullName: String
    get() = "$name $surname"

// Extension function dla bibliotecznej klasy, ktorej normalnie nie mozemy rozszerzyc
fun String.removePolishCharacters() : String {
    val normalizedText = Normalizer.normalize(this, Normalizer.Form.NFD)
    return normalizedText.replace("\\p{M}".toRegex(), "")
}

// Extension function dla parametryzowanego typu - zadziala tylko dla listy adresow!
fun List<Address>.withFilledCity() = filter { it.city != null }


// Extension function dla *dowolnego* typu
fun <T> T.logInfo() {
    println("${LocalDate.now()} : object info = $this")
}