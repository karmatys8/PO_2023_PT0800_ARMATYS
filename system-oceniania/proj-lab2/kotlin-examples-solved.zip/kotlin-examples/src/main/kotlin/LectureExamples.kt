import java.lang.IllegalStateException
import java.time.LocalDate
import java.util.UUID
import kotlin.math.pow
import kotlin.reflect.KProperty


class Task {
    fun execute() {
    }
}

class ServiceManagerProvider(var name: String, val id: UUID) {
    var counter: Int = 0
        private set

    fun execute(task : Task) {
        task.execute()
        counter++
    }
}

data class Point(val x: Double, val y: Double)

object HelloService {
    var serviceName = "Ugly singleton"

    fun greetings() = println(serviceName)

}

open class Animal

class Dog(val name: String) : Animal()

data class User(
    val login: String,
    val birthDate: LocalDate = LocalDate.of(1970, 1, 1)
)


fun User.isYoungerThan(date: LocalDate): Boolean {
    return this.birthDate < date
}

val User.birthYear: Int
    get() {
        return birthDate.year
    }

sealed class Shape {
    class Circle(val radius: Float) : Shape()
    class Rectangle(val width: Float, val height: Float) : Shape()
    class Square(val length: Float) : Shape()
}

class Container {
    var data : String by Verbose()
}

class Verbose {
    operator fun getValue(objectRef: Any?, property: KProperty<*>): String {
        return "$objectRef, thank you for delegating '${property.name}' to me!"
    }

    operator fun setValue(objectRef: Any?, property: KProperty<*>, value: String) {
        println("$value has been assigned to '${property.name}' in $objectRef.")
    }
}

fun main() {
    val manager = ServiceManagerProvider("Allmighty Service", UUID.randomUUID())
    manager.execute(Task())
    println(manager.counter)
    manager.name = "Evenmorepowerful Service"

    // data class usage
    val p1 = Point(1.5, 2.0)
    val p2 = p1.copy()

    println(p1.x) // generated getter
    println(p1 == p2) // true, equals() compares (x, y)
    println(p1) // prints "Point(x=1.5, y=2.0)"

    // object usage
    HelloService.serviceName = "Ugly global modification"
    HelloService.greetings()

    // collections covariance
    val dogs: List<Dog> = listOf(Dog("Rex"), Dog("Chopper"))
    val animals: List<Animal> = dogs

    // named arguments
    val me = User(login = "Michal", birthDate = LocalDate.of(1990, 11, 7))
    val myFriend = User(login = "Borubar")
    val otherFriend = User("Blahaj")
    val otherFriendCopy = otherFriend.copy(birthDate = LocalDate.of(1978, 1, 1))

    // null safety
    // error
//    val county: String = null

    val country: String? = null
    // error
    // val length : Int = country.length

    if (country != null) {
        val length: Int = country.length
        println(length)
    }

    val length: Int? = country?.length
    println(length ?: 0)

    // extensions
    if (me.isYoungerThan(LocalDate.now())) {
        println(me.birthYear)
    }

    // let, also, apply
    me.let { println(it.birthDate) }
    country?.let { println(it) } // prints only if country's not null

    val newDate = me.birthDate
        .plusDays(7)
        .minusMonths(3)
        .also { println(it) } // debug print this stage!
        .plusYears(1)

    me.run { println(birthDate) }
    country?.run { println(this) } // prints only if country's not null

    val names = mutableListOf<String>().apply {
        add("Adam")
        add("Ewa")
    }

    with(names) {
        add("Kain")
        add("Abel")
    }

    // Sealed classes

    val shape: Shape = Shape.Circle(10.0f)

    val area = when (shape) {
        is Shape.Circle -> 3.14 * shape.radius * shape.radius
        is Shape.Square -> shape.length.pow(2)
        is Shape.Rectangle -> shape.width * shape.height
    }

    operator fun Point.unaryMinus() = Point(-x, -y)

    val point = Point(10.0, 20.0)
    println(-point)  // prints "Point(x=-10, y=-20)"

    // Property delegates
    val container = Container()
    println(container.data) // prints: Container@63c12fb0, thank you for delegating 'data' to me!
    container.data = "test" // prints: test has been assigned to 'data' in Container@63c12fb0.

    // Destructuring
    val (login, birthdate) = me

    // Nothing
    val quantumComputer = TODO() // this code will throw NotImplementedError

    fun logAndThrow(e: Throwable): Nothing {
        println("error occured ${e.message}")
        throw e
    }

    val countryLength = country?.length ?: logAndThrow(IllegalStateException("empty country"))
}
