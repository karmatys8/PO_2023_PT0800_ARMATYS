package model.java;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.stream.Stream;

public class PersonLoader {

    private final String filePath;

    public PersonLoader(String filePath) {
        this.filePath = filePath;
    }

    public Stream<Person> loadPersonsFromFile() throws IOException {
        return Files.lines(Path.of(filePath))
                .map(this::loadPerson);
    }

    private Person loadPerson(String line) {
        String[] lineParts = line.split(";");
        if (lineParts.length < 2) {
            throw new IllegalArgumentException("Person data should have at least name and surname");
        }
        var name = lineParts[0];
        var surname = lineParts[1];
        Address address = null;
        if (lineParts.length > 2) {
            address = loadAddress(lineParts);
        }
        return new Person(name, surname, address);
    }

    private Address loadAddress(String[] lineParts) {
        Address address;
        var addressBuilder = Address.builder();

        addressBuilder.city(lineParts[2]);

        if (lineParts.length > 3) {
            addressBuilder.postalCode(lineParts[3]);
        }

        if (lineParts.length > 4) {
            addressBuilder.street(lineParts[4]);
        }

        if (lineParts.length > 5) {
            addressBuilder.province(lineParts[5]);
        }

        if (lineParts.length > 6) {
            addressBuilder.details(lineParts[6]);
        }

        address = addressBuilder.build();
        return address;
    }
}
